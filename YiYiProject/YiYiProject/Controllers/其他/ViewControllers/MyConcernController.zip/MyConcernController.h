//
//  MyConcernController.h
//  YiYiProject
//
//  Created by lichaowei on 15/1/2.
//  Copyright (c) 2015年 lcw. All rights reserved.
//

#import "MyViewController.h"
/**
 *  我的关注
 */
@interface MyConcernController : MyViewController


@property(nonatomic,assign)BOOL isRePrepareNetData_shop;//是否重新请求关注商家信息

@property(nonatomic,assign)BOOL isRePrepareNetData_pinpai;//是否重新请求关注品牌信息

@property(nonatomic,retain)NSString *uid;

@end
